﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            ShowForm();
            comboBox();
        }
        private void ShowForm()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from RubricLevel", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void comboBox()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Rubric", con);
            SqlDataAdapter dat = new SqlDataAdapter(cmd);
            DataTable dtable = new DataTable();
            dat.Fill(dtable);
            comboBox1.DataSource = dtable;
            comboBox1.DisplayMember = "Rubric";
            comboBox1.ValueMember = "ID";
        } 
        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into RubricLevel values ( @RubricId, @Details, @MeasurementLevel)", con);

           
            cmd.Parameters.AddWithValue("@Details", textBox3.Text);
            cmd.Parameters.AddWithValue("@MeasurementLevel", textBox2.Text);
            cmd.Parameters.AddWithValue("@RubricId", comboBox1.Text);


            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully added");
            ShowForm();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            if (textBox3.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update RubricLevel set Details='" + textBox3.Text + "' WHERE Id='" + textBox4.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            if (textBox2.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update RubricLevel set MeasurementLevel='" + textBox2.Text + "' WHERE Id='" + textBox4.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            ShowForm();
            MessageBox.Show("Successfully Updated");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM RubricLevel WHERE  Id= '" + textBox4.Text + "' OR  Details= '" + textBox3.Text + "' OR MeasurementLevel='" + textBox2.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted");
            ShowForm();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from RubricLevel WHERE  Id Like '%" + textBox5.Text + "%' OR RubricId Like '%" + textBox5.Text + "%' OR Details Like '%" + textBox5.Text + "%' OR MeasurementLevel Like '%" + textBox5.Text + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
