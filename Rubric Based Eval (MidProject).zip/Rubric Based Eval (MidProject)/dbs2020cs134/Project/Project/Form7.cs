﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
            Show();
            combo();
            comboBo();
            comboBox();
        }

        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from StudentResult", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void comboBox()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from AssessmentComponent", con);
            SqlDataAdapter dat = new SqlDataAdapter(cmd);
            DataTable dtable = new DataTable();
            dat.Fill(dtable);
            comboBox1.DataSource = dtable;
            comboBox1.DisplayMember = "AssessmentComponent";
            comboBox1.ValueMember = "ID";
        }

        private void comboBo()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from RubricLevel", con);
            SqlDataAdapter dat = new SqlDataAdapter(cmd);
            DataTable dtable = new DataTable();
            dat.Fill(dtable);
            comboBox2.DataSource = dtable;
            comboBox2.DisplayMember = "RubricLevel";
            comboBox2.ValueMember = "ID";
        }


        private void combo()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter dat = new SqlDataAdapter(cmd);
            DataTable dtable = new DataTable();
            dat.Fill(dtable);
            comboBox3.DataSource = dtable;
            comboBox3.DisplayMember = "Student";
            comboBox3.ValueMember = "ID";
        }
        private void button6_MouseEnter(object sender, EventArgs e)
        {
         
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.Gold;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.Transparent;
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gold;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Transparent;
        }

        private void button7_MouseEnter(object sender, EventArgs e)
        {
            button7.BackColor = Color.Gold;
        }

        private void button7_MouseLeave(object sender, EventArgs e)
        {
            button7.BackColor = Color.Transparent;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into StudentResult values (@StudentId, @AssessmentComponentId, @RubricMeasurementId,@EvaluationDate)", con);

            cmd.Parameters.AddWithValue("@StudentId", comboBox3.Text);
            cmd.Parameters.AddWithValue("@AssessmentComponentId", comboBox1.Text);
            cmd.Parameters.AddWithValue("@RubricMeasurementId", comboBox2.Text);
            cmd.Parameters.AddWithValue("@EvaluationDate", DateTime.Now);

            cmd.ExecuteNonQuery();
            Show();
            MessageBox.Show("Successfully added");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Update StudentResult Set AssessmentComponentId=@AssessmentComponentId,RubricMeasurementId=@RubricMeasurementId,Evaluationdate=@Evaluationdate where StudentId="+ dataGridView1.CurrentRow.Cells[0].Value.ToString()+ "and AssessmentComponentId=" + dataGridView1.CurrentRow.Cells[1].Value.ToString(), con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.Parameters.AddWithValue("@AssessmentComponentId", comboBox1.Text);
            cmd.Parameters.AddWithValue("@RubricMeasurementId", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Evaluationdate", DateTime.Now);
           
             cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");
            Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("delete from StudentResult where AssessmentComponentId="+comboBox1.Text+ " AND StudentId="+comboBox3.Text, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted");
            Show();
        }
    }
}
