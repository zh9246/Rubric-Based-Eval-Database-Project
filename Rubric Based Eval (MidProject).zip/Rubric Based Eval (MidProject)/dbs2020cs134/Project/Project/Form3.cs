﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            Show();
            comboBox();
        }

        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Rubric", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button8_Click(object sender, EventArgs e)
        {

        }
        public void delet()
        {

            
           
        }

        private void button7_Click(object sender, EventArgs e)
        {

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Delete from StudentResult where RubricMeasurementId in (select id from RubricLevel where RubricId="+textBox3.Text+")", con);
            cmd.ExecuteNonQuery();


            con = Configuration.getInstance().getConnection();
            cmd = new SqlCommand("DELETE FROM RubricLevel WHERE RubricId= "+textBox3.Text, con);
            cmd.ExecuteNonQuery();



            con = Configuration.getInstance().getConnection();
            cmd = new SqlCommand("DELETE FROM StudentResult WHERE AssessmentComponentId in(Select Id from AssessmentComponent where RubricId in (select Id from  Rubric where Id= " + textBox3.Text+"))", con);
            cmd.ExecuteNonQuery();

            con = Configuration.getInstance().getConnection();
            cmd = new SqlCommand("DELETE FROM AssessmentComponent WHERE RubricId= " + textBox3.Text, con);
            cmd.ExecuteNonQuery();

            


            con = Configuration.getInstance().getConnection();
            cmd = new SqlCommand("DELETE FROM Rubric WHERE Id= " + textBox3.Text, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted");
            Show();

        }

        private void comboBox()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Clo", con);
            SqlDataAdapter dat = new SqlDataAdapter(cmd);
            DataTable dtable = new DataTable();
            dat.Fill(dtable);
            comboBox1.DataSource = dtable;
            comboBox1.DisplayMember = "Clo";
            comboBox1.ValueMember = "ID";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Rubric values (@Id, @Details, @CloId)", con);

            cmd.Parameters.AddWithValue("@Id", textBox3.Text);
            cmd.Parameters.AddWithValue("@Details", textBox1.Text);
            cmd.Parameters.AddWithValue("@CloId", comboBox1.Text);


            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully added");
            Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            if (textBox1.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Rubric set Details='" + textBox1.Text + "' WHERE Id='" + textBox3.Text + "'", con);
                cmd.ExecuteNonQuery();
                Show();
            }
            MessageBox.Show("Updated Successfully");
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Rubric WHERE  Id Like '%" + textBox5.Text + "%' OR Details Like '%" + textBox5.Text + "%' OR CloId Like '%" + textBox5.Text + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
           
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gold;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Transparent;
        }

        private void button6_MouseEnter(object sender, EventArgs e)
        {
            button6.BackColor = Color.Gold;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            button6.BackColor = Color.Transparent;
        }

        private void button7_MouseEnter(object sender, EventArgs e)
        {
            button7.BackColor = Color.Gold;
        }

        private void button7_MouseLeave(object sender, EventArgs e)
        {
            button7.BackColor = Color.Transparent;
        }
    }
}
