﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            ShowForm();
        }
        private void ShowForm()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Assessment", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gold;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Transparent;
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.Gold;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.Transparent;
        }

        private void button6_MouseEnter(object sender, EventArgs e)
        {
            button6.BackColor = Color.Gold;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            button6.BackColor = Color.Transparent;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Assessment values ( @Title, @DateCreated,@TotalMarks,@TotalWeightage)", con);

            
            cmd.Parameters.AddWithValue("@Title", textBox2.Text);
            cmd.Parameters.AddWithValue("@DateCreated", DateTime.Now);
            cmd.Parameters.AddWithValue("@TotalMarks", textBox4.Text);
            cmd.Parameters.AddWithValue("@TotalWeightage", textBox5.Text);
            
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully added");
            ShowForm();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            if (textBox2.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Assessment set Title='" + textBox2.Text + "' WHERE Id='" + textBox1.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            
            if (textBox4.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Assessment set TotalMarks='" + textBox4.Text + "' WHERE Id='" + textBox1.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            if (textBox5.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Assessment set TotalWeightage='" + textBox5.Text + "' WHERE Id='" + textBox1.Text + "'", con);
                cmd.ExecuteNonQuery();
            }

            ShowForm();
            MessageBox.Show("Successfully Updated");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM AssessmentComponent WHERE AssessmentId=(SELECT Id From Assessment where Id=" + textBox1.Text + ")", con);
            cmd.ExecuteNonQuery();

             con = Configuration.getInstance().getConnection();
             cmd = new SqlCommand("DELETE FROM Assessment WHERE  Id= '" + textBox1.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted");
            ShowForm();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Assessment WHERE Id Like '%" + textBox6.Text + "%' OR Title Like '%" + textBox6.Text + "%' OR DateCreated Like '%" + textBox6.Text + "%' OR TotalMarks Like '%" + textBox6.Text + "%' OR TotalWeightage Like'%" + textBox6.Text + "%' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
