﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            comboBox1.Height = 150;
            ShowForm();
        }
        private void ShowForm()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Student values (@FirstName, @LastName, @Contact,@Email,@RegistrationNumber, @Status)", con);

            
            cmd.Parameters.AddWithValue("@FirstName", textBox6.Text);
            cmd.Parameters.AddWithValue("@LastName", textBox2.Text);
            cmd.Parameters.AddWithValue("@Contact", textBox3.Text);
            cmd.Parameters.AddWithValue("@Email", textBox4.Text);
            cmd.Parameters.AddWithValue("@RegistrationNumber", textBox7.Text);
            cmd.Parameters.AddWithValue("@Status", comboBox1.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully added");
            ShowForm();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            
            if (textBox2.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Student set LastName='" + textBox2.Text + "' WHERE Id='" + textBox1.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            if (textBox3.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Student set Contact='" + textBox3.Text + "' WHERE Id='" + textBox1.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            if (textBox7.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Student set RegistrationNumber='" + textBox7.Text + "' WHERE Id='" + textBox1.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            if (comboBox1.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Student set Status='" + comboBox1.Text + "' WHERE RegistrationNumber='" + textBox7.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            if (textBox6.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Student set FirstName='" + textBox6.Text + "' WHERE RegistrationNumber='" + textBox7.Text + "'", con);
                cmd.ExecuteNonQuery();
            }
            if (textBox4.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update Student set Email='" + textBox4.Text + "' WHERE RegistrationNumber='" + textBox7.Text + "'", con);
                cmd.ExecuteNonQuery();
            }

            ShowForm();
            MessageBox.Show("Successfully Updated");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM StudentAttendance WHERE  StudentId="+textBox1.Text, con);
            cmd.ExecuteNonQuery();


             con = Configuration.getInstance().getConnection();
             cmd = new SqlCommand("DELETE FROM Student WHERE  Id=" + textBox1.Text, con);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Successfully Deleted");
            ShowForm();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * FROM Student WHERE FirstName= '" + textBox6.Text + "' OR LastName= '" + textBox2.Text + "' OR Contact= '" + textBox3.Text + "' OR Email='" + textBox7.Text + "' OR RegistrationNumber='" + textBox4.Text + "' OR Status='" + comboBox1.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student WHERE  FirstName Like '%" + textBox5.Text + "%' OR LastName Like '%" + textBox5.Text + "%' OR Contact Like '%" + textBox5.Text + "%' OR Email Like '%" + textBox5.Text + "%' OR RegistrationNumber Like '%" + textBox5.Text + "%' OR Status Like '%" + textBox5 + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
           
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gold;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Transparent;
        }

        private void button6_MouseEnter(object sender, EventArgs e)
        {
            button6.BackColor = Color.Gold;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            button6.BackColor = Color.Transparent;
        }

        private void button7_MouseEnter(object sender, EventArgs e)
        {
            button7.BackColor = Color.Gold;
        }

        private void button7_MouseLeave(object sender, EventArgs e)
        {
            button7.BackColor = Color.Transparent;
        }
    }
}
