﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Project
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            Show();
        }
        private void Show()
                {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Clo", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Clo values ( @Name, @DateCreated,@DateUpdated)", con);

            cmd.Parameters.AddWithValue("@Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@DateCreated",DateTime.Now );
            cmd.Parameters.AddWithValue("@DateUpdated", DateTime.Now);
            
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully added");
            Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //var con = Configuration.getInstance().getConnection();

            if (textBox2.Text != "")
            {
               //SqlCommand cmd = new SqlCommand("update Clo set Name='" + textBox2.Text + "'   WHERE Id='" + textBox1.Text+"'", con);
                //cmd.ExecuteNonQuery();
                //Show();
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("update Clo set Name=@Name, DateUpdated=@DateUpdated WHERE Id=@Id", con);

                cmd.Parameters.AddWithValue("@Name", textBox2.Text);
                cmd.Parameters.AddWithValue("@DateUpdated", DateTime.Now);
                cmd.Parameters.AddWithValue("@Id", textBox1.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Updated");
                Show();
            }
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM AssessmentComponent WHERE RubricId= '" + textBox1.Text + "' ", con);
            cmd.ExecuteNonQuery();

             con = Configuration.getInstance().getConnection();
            cmd = new SqlCommand("DELETE FROM Rubric WHERE CloId= '" + textBox1.Text + "' ", con);
            cmd.ExecuteNonQuery();

            

            con = Configuration.getInstance().getConnection();
             cmd = new SqlCommand("DELETE FROM Clo WHERE Id= '" + textBox1.Text + "' OR Name= '" + textBox2.Text + "' ", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted");
            Show();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Clo WHERE  Id Like '%" + textBox5.Text + "%' OR Name Like '%" + textBox5.Text + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gold;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Transparent;
        }

        private void button6_MouseEnter(object sender, EventArgs e)
        {
            button6.BackColor = Color.Gold;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            button6.BackColor = Color.Transparent;
        }

        private void button7_MouseEnter(object sender, EventArgs e)
        {
            button7.BackColor = Color.Gold;
        }

        private void button7_MouseLeave(object sender, EventArgs e)
        {
            button7.BackColor = Color.Transparent;
        }
    }
}
